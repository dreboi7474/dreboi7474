﻿using System;

namespace EspionSpotify.Updater.Utilities
{
    internal class ReleaseAssetNotFoundException : ApplicationException
    {
    }
}