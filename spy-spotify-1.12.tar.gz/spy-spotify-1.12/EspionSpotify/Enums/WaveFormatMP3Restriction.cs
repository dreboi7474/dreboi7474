﻿namespace EspionSpotify.Enums
{
    public enum WaveFormatMP3Restriction
    {
        Channel,
        SampleRate
    }
}