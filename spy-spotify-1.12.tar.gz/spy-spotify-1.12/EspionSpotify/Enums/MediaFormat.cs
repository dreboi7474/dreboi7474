﻿namespace EspionSpotify.Enums
{
    public enum MediaFormat
    {
        Mp3,
        Wav
    }
}