﻿namespace EspionSpotify.Enums
{
    public enum SilenceAnalyzer
    {  
        None,
        TrimEnd,
        TrimStart
    }
}