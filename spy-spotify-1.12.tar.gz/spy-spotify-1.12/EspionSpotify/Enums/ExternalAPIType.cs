﻿namespace EspionSpotify.Enums
{
    public enum ExternalAPIType
    {
        None = - 1,
        LastFM = 0,
        Spotify
    }
}