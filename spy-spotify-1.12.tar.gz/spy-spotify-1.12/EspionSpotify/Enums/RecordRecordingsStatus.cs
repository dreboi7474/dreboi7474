﻿namespace EspionSpotify.Enums
{
    public enum RecordRecordingsStatus
    {
        Skip = 0,
        Overwrite,
        Duplicate
    }
}