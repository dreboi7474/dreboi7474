﻿namespace EspionSpotify.Enums
{
    public enum TitleSeparatorType
    {
        None,
        Dash,
        Parenthesis
    }
}