﻿namespace EspionSpotify.Enums
{
    public enum LanguageType
    {
        en = 0,
        fr // French
    }
}