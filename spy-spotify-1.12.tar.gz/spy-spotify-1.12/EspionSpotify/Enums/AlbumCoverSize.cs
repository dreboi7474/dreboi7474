﻿namespace EspionSpotify.Enums
{
    public enum AlbumCoverSize
    {
        small,
        medium,
        large,
        extralarge
    }
}