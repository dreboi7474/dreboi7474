﻿namespace EspionSpotify.Enums
{
    public enum LastFMNodeStatus
    {
        ok,
        failed
    }
}