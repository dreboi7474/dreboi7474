﻿namespace EspionSpotify
{
    public static class Constants
    {
        public const string SPYTIFY = "Spytify";

        public const string SPOTIFY = "Spotify";
        public const string SPOTIFYFREE = "Spotify Free";
        public const string SPOTIFYPREMIUM = "Spotify Premium";
        public const string ADVERTISEMENT = "Advertisement";

        public const string UNTITLED_ALBUM = "Untitled";
    }
}