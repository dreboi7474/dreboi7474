﻿using System.Windows.Forms;

namespace EspionSpotify.Controls
{
    public class MetroTrackBar : MetroFramework.Controls.MetroTrackBar
    {
        protected override void OnMouseWheel(MouseEventArgs e)
        {
        }
    }
}