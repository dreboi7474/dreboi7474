---
name: Feature request
about: Suggest an new feature to improve Spytify
title: ''
labels: feature ✨
assignees: ''

---


