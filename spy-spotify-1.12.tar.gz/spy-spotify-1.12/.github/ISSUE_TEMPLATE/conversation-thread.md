---
name: Conversation thread
about: Create a new conversation thread or ask a question to be moved in Discussions section.
title: ''
labels: "question \U0001F4AC"
assignees: ''

---

You can now use the Discussions section
https://github.com/jwallet/spy-spotify/discussions
